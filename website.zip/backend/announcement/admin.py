from django.contrib import admin
from .models import Announcement

admin.site.register(Announcement)
